package com.example.demo_ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEcomApplicationTests {

	@Test
	void contextLoads() {
	}

}
