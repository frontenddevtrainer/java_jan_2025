package com.example.demo_ecom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.http.*;

import com.example.demo_ecom.model.Product;
import com.example.demo_ecom.service.ProductService;

import java.util.List;
import java.util.Map;

// /api/v1/admin/products/1 /2

@RestController
@RequestMapping("/api/v1/admin/products")
public class AdminAPIController {
	
	@Autowired
	private ProductService productservice;
	
	@GetMapping
	public List<Product> getProducts(){
		return productservice.getAllProducts();
	}
	
	@PostMapping
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		Product savedProduct = productservice.saveProduct(product);
		return ResponseEntity.ok(savedProduct);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Product> deleteProduct(@PathVariable Long id) {
		boolean isDeleted = productservice.deleteProduct(id);
		if(isDeleted) {
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.notFound().build();
	}
	
	@PatchMapping("/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Map<String, Object> updates){
		Product updatedProduct = productservice.updateProduct(id, updates);
		if(updatedProduct == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(updatedProduct);
	}

}
