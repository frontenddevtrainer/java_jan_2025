package com.example.demo_ecom.model;

import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.*;

import jakarta.validation.constraints.*;


@Data
@Entity
@Table(name = "products")
public class Product {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
	
	@Column(name = "product_name", nullable = false, unique = true)
	@NotNull
	@Size(max=200)
    private String name;
	
    private String description;
    
    
    @Positive
    private double price;
    
    @PositiveOrZero
    private int stock;
   
    
}
