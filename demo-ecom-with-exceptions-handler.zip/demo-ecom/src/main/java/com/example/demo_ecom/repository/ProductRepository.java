package com.example.demo_ecom.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.*;

import com.example.demo_ecom.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	
	List<Product> findByName(String name);
	
	@Query("SELECT p FROM Product p")
	List<Product> findAllProduct();
	 
	@Query("SELECT p FROM Product p WHERE p.name LIKE %:name%")
	List<Product> findAllProductByName(@Param("name") String name);
}
