package com.example.demo_ecom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo_ecom.service.ProductService;

@Controller
public class AdminController {

    @Autowired
    private ProductService productService;

    @GetMapping("/admin/products")
    public String getAllProducts(Model model) {
    	System.out.println(productService.getAllProducts());
        model.addAttribute("products", productService.getAllProducts());
        return "admin/products";
    }
}
