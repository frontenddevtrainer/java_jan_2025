package com.example.demo_ecom.service;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

import com.example.demo_ecom.repository.*;
import com.example.demo_ecom.model.*;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
    	
        return productRepository.findById(id).orElse(null);
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public boolean deleteProduct(Long id) {
    	if(productRepository.existsById(id)) {
    		productRepository.deleteById(id);
    		return true;
    	}
    	return false;
        
    }
    
    
    public Product updateProduct(Long id, Map<String, Object> updates) {
    	
    	return productRepository.findById(id)
   
    	.map((Product product) -> {
    		
    		updates.forEach((String key, Object value) -> {
    			
    			switch(key) {
    				case "name": 
    					product.setName((String) value);
    				break;
    				
    				case "description": 
    					product.setDescription((String) value);
    				break;
    				
    				case "price": 
    					product.setPrice(Double.parseDouble(value.toString()));
    				break;
    				
    				case "stock": 
    					product.setStock(Integer.parseInt(value.toString()));
    				break;
    				default: 
    					throw new IllegalArgumentException("Invalid Field " + key);
    			}
    			
    		});
    		
    		return productRepository.save(product);
    		
    	})
    			
    			
    	.orElse(null);
    	
    }
}


