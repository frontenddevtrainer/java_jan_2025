package com.example.demo_ecom.model;

import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Data
@Entity
public class Product {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    // private String description;
//    private double price;
//    private int stock;
    
    public Long getId() {
    	return this.id;
    } 
    
    public void setId(Long id) {
    	this.id = id;
    } 
    
    public String getName() {
    	return this.name;
    } 
    
    public void setName(String name) {
    	this.name = name;
    } 
    
}
