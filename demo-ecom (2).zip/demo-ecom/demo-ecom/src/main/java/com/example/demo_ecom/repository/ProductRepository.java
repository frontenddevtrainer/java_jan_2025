package com.example.demo_ecom.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo_ecom.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	
}
