package com.example.demo_ecom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo_ecom.model.Product;
import com.example.demo_ecom.service.ProductService;

import java.util.List;

@RestController
public class AdminAPIController {
	
	@Autowired
	private ProductService productservice;
	
	@GetMapping("/api/v1/admin/products")
	public List<Product> getProducts(){
		return productservice.getAllProducts();
	}

}
